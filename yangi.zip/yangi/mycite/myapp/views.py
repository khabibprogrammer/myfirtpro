from django.shortcuts import render

# Create your views here.

from django.http import HttpResponse
from django.template import loader
from .models import Person

def index(request):
    mymembers = Person.objects.all().values()
    template = loader.get_template('index.html')
    context = {
        'mymembers':mymembers,
    }
    return HttpResponse(template.render(context,request))

def detail(request,id):
    mymembers = Person.objects.get(id=id)
    template = loader.get_template('detail.html')
    context = {
        'mymembers': mymembers
    }
    return HttpResponse(template.render(context,request))
    